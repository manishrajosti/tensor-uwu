from setuptools import setup, find_packages

setup(
    name="tensor-uwu",
    version="0.1.0",
    description="An amazing package for arch linux uwu",
    author="Manish Raj Osti",
    author_email="manishrajosti1@gmail.com",
    url="https://github.com/manishrajosti/tensor-uwu",
    packages=['tensor-uwu']
)
